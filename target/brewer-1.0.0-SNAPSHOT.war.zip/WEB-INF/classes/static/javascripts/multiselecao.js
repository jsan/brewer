Brewer = Brewer || {};

Brewer.MultiSelecao = (function() {
	
	function MultiSelecao() {
		this.statusBtn = $('.js-status-btn');
		this.selecaoCheckbox = $('.js-selecao');
	}
	
	MultiSelecao.prototype.iniciar = function() {
		this.statusBtn.on('click', onStatusBtnClicado.bind(this));
	}
	
	function onStatusBtnClicado(event) {
		var botaoClicado = $(event.currentTarget); // gets tag that was clicked: <button>
		var status = botaoClicado.data('status');  // gets data:status value: ATIVAR/DESATIVAR
		
		var checkBoxSelecionados = this.selecaoCheckbox.filter(':checked'); // gets all the checked
		var codigos = $.map(checkBoxSelecionados, function(c) {
			return $(c).data('codigo'); 			// gets all data:codigo values and puts into var codigos 
		});
		
		if (codigos.length > 0) {
			$.ajax({
				url: '/brewer/usuarios/status',
				method: 'PUT',
				data: {
					codigos: codigos,
					status: status
				}, 
				success: function() {
					window.location.reload();
				}
			});
			
		}
	}
	
	return MultiSelecao;
	
}());

$(function() {
	var multiSelecao = new Brewer.MultiSelecao();
	multiSelecao.iniciar();
});
