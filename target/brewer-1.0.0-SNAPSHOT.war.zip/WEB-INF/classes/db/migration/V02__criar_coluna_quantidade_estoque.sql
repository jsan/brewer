ALTER TABLE cerveja
 add quantidade_estoque INTEGER;